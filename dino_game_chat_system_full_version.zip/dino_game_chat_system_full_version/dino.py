import pygame,sys
from pygame.locals import *  # 导入pygame常量

SCREENWIDTH=822
SCREENHEIGHT=350
FPS=15



# 定义背景对象
class MyMap():
    def __init__(self,x,y):  # 构造函数
        self.bg_before =pygame.image.load('grass.jpg').convert_alpha()  # 进行图形判断，将背景与其相关的图片透明化
        self.bg=pygame.transform.scale(self.bg_before, (822, 350))
        self.x=x
        self.y=y


    def map_rolling(self):  # 滚动
        if self.x < -822:
            self.x=822
        else:
            self.x-=10  # 每帧以5个像素，表示像素移动的距离

    def map_update(self):
            SCREEN.blit(self.bg,(self.x,self.y))

# 恐龙类
from itertools import cycle  # 让我们读取反复不断的用
class Dinosaur():
    def __init__(self):
        # 初始化恐龙图片的矩阵
        self.rect=pygame.Rect(0,0,0,0)
        self.jumpState=False  # 状态
        self.jumpHeight=150  # 跳跃高度
        self.lowest_y=150  # 步行高度
        self.jumpValue=0  # 跳跃速度
        # 加载图片
        self.dinosaurIndex=0
        self.dinosaurIndexGen=cycle([0,1,2])
        
        #transform size of the dino
        kong2 = pygame.image.load('long-1.png').convert_alpha()
        kong3 = pygame.image.load('long-2.png').convert_alpha()
        kong4 = pygame.image.load('long-3.png').convert_alpha()
            
        self.dinosaur_img=(
            pygame.transform.scale(kong2, (160, 160)),
            pygame.transform.scale(kong3, (160, 160)),
            pygame.transform.scale(kong4, (160, 160))
        )
                                  
                                  
        # 加载声音
        self.jump_audio=pygame.mixer.Sound('jump.wav')
        self.game_over_audio = pygame.mixer.Sound('game_over.wav')
        self.rect.size=self.dinosaur_img[0].get_size()
        self.x=50
        self.y=self.lowest_y
        self.rect.topleft=(self.x,self.y)

        #create a mask for dino
        self.mask = pygame.mask.from_surface(self.dinosaur_img[0],50)
        

    def jump(self):
        self.jumpState = True

    def move(self):
        if self.jumpState:
            if self.rect.y >= self.lowest_y:
                self.jumpValue = -18  # 向上移动10个矩阵
            if self.rect.y <= self.lowest_y - self.jumpHeight:
                self.jumpValue = 18
            self.rect.y += self.jumpValue
            if self.rect.y >= self.lowest_y:
                self.jumpState = False  # 关闭跳跃状态


    def draw_dinosaur(self):
        # 匹配恐龙动图
        dinosaurIndex=next(self.dinosaurIndexGen)
        SCREEN.blit(self.dinosaur_img[dinosaurIndex],
                    (self.x,self.rect.y))
        #Draw mask of this dinosaur
        self.mask = pygame.mask.from_surface(self.dinosaur_img[dinosaurIndex],50)

        


# 障碍物类
import random
class Obstacle():
    score = 1 #分数
    def __init__(self):
        self.rect=pygame.Rect(0,0,0,0)
    
        self.stone_before=pygame.image.load('stone.png').convert_alpha()
        self.stone=pygame.transform.scale(self.stone_before, (60, 60))
        self.cacti=pygame.image.load('cactus.png').convert_alpha()
        self.cacti=pygame.transform.scale(self.cacti, (60, 60))


        # 分数图片
        self.numbers = (
            pygame.image.load("0.png").convert_alpha(),
            pygame.image.load("1.png").convert_alpha(),
            pygame.image.load("2.png").convert_alpha(),
            pygame.image.load("3.png").convert_alpha(),
            pygame.image.load("4.png").convert_alpha(),
            pygame.image.load("5.png").convert_alpha(),
            pygame.image.load("6.png").convert_alpha(),
            pygame.image.load("7.png").convert_alpha(),
            pygame.image.load("8.png").convert_alpha(),
            pygame.image.load("9.png").convert_alpha(),
        )

        
        r=random.randint(0,1)
        if r==0:
            self.image=self.stone
        else:
            self.image=self.cacti
        self.rect.size=self.image.get_size()
        self.width,self.height=self.rect.size
        self.x=840
        self.y=280-(self.height/2)
        self.rect.center=(self.x,self.y)

        #create mask for the obstacle
        self.mask = pygame.mask.from_surface(self.image,50)

        


    def obstacle_move(self):
        self.rect.x -= 10

    def draw_obstacle(self):
        SCREEN.blit(self.image,(self.rect.x,self.rect.y))

    def getScore(self):
        tmp = self.score
        self.score = 0
        return tmp

    def showScore(self, score):
        # 在窗体顶部中间的位置显示分数
        self.scoreDigits = [int(x) for x in list(str(score))]
        totalWidth = 0  # 要显示所有数字的总宽度
        for digit in self.scoreDigits:
            # 获取积分图片的宽度
            totalWidth += self.numbers[digit].get_width()
        # 分数横向位置
        Xoffset = (SCREENWIDTH - totalWidth) / 2
        for digit in self.scoreDigits:
            # 绘制分数
            SCREEN.blit(self.numbers[digit], (Xoffset, SCREENHEIGHT * 0.1))
            # 数字增加也改变位置
            Xoffset += self.numbers[digit].get_width()


# 游戏结束方法
def game_over():
    # 获取窗体宽度和高
    screen_w = pygame.display.Info().current_w
    screen_h = pygame.display.Info().current_h
    # 加载游戏结束的图片
    over_before=pygame.image.load('gameover.png').convert_alpha()
    over_img=pygame.transform.scale(over_before, (300, 100))
    # 游戏结束的图片控制在窗体的中间位置
    SCREEN.blit(over_img, ((screen_w - over_img.get_width()) / 2,
                (screen_h - over_img.get_height()) / 2))

def intro():
    intro = True

    global SCREEN,FPSCLOCK  # 全局变量global
    pygame.init()  # 初始化
    FPSCLOCK=pygame.time.Clock()
    SCREEN=pygame.display.set_mode((SCREENWIDTH,SCREENHEIGHT))
    pygame.display.set_caption('google small game')

    bg1 = MyMap(0,0)
    dinosaur = Dinosaur()
    font = pygame.font.Font('freesansbold.ttf', 25) 
    text = font.render("Press 'SPACE' to Set Me Free !!!",True, [255,99,71])
    screen_w = pygame.display.Info().current_w
    screen_h = pygame.display.Info().current_h

    clock = pygame.time.Clock()
    

    while intro:
        clock.tick(60)
        

        if intro:
            bg1.map_update()
            dinosaur.draw_dinosaur()
            SCREEN.blit(text,((screen_w - text.get_width()/(1.5)) / 2,
                (screen_h - text.get_height()) / 2))

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                intro = False
                pygame.quit()
                quit()

            if event.type == pygame.K_ESCAPE:
                intro = False
                pygame.quit()
                quit()


            #Jump to the mainGame()
            if event.type == KEYDOWN and event.key == K_SPACE:
                dinosaur.jump_audio.play()
                intro = False

        pygame.display.update()
        FPSCLOCK.tick(FPS)



def mainGame():
    over=False
    pygame.init()  # 初始化
    SCREEN=pygame.display.set_mode((SCREENWIDTH,SCREENHEIGHT))
    pygame.display.set_caption('google small game')
    # 创建地图
    bg1=MyMap(0,0)
    bg2=MyMap(822,0)
    # 创建恐龙对象
    dinosaur = Dinosaur()
    # 创建一个障碍物集合
    addObasacletime = 0  # 计时器
    list=[]

    final_score = 0

    last_bx, last_by = 0,0

    
##    while True:
##        # 事件监控
##        for event in pygame.event.get(): 
##            if event.type==pygame.QUIT:
##                #quitt = True
##                
##                pygame.display.quit()
##                quit()
##                sys.exit()

    clock = pygame.time.Clock()
    run  = True 
    while run: 
        clock.tick(60)

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                run = False

            if event.type == pygame.K_ESCAPE:
                run = False

            # 单击空格，跳跃
            if event.type == KEYDOWN and event.key == K_SPACE:
                if dinosaur.rect.y >= dinosaur.lowest_y:
                    dinosaur.jump()
                    dinosaur.jump_audio.play()
                

        if over==False:
            bg1.map_update()  # 出现
            bg1.map_rolling()  # 滚动
            bg2.map_update()  # 出现
            bg2.map_rolling()  # 滚动
            dinosaur.move()  # 恐龙移动
            dinosaur.draw_dinosaur()  # 显示相应动画

            bx, by = (dinosaur.rect[0], dinosaur.rect[1])

            if addObasacletime>=1300:
                r=random.randint(0,100)
                if r > 40:
                    obstacle=Obstacle()
                    list.append(obstacle)
                addObasacletime=0


            for i in range(len(list)):
                if run:
                    list[i].obstacle_move()  # 出现的障碍物移动
                    list[i].draw_obstacle()  # 显示出现的障碍物


                    offset_x = bx - list[i].rect[0]
                    offset_y = by - list[i].rect[1]

                    overlap = list[i].mask.overlap(dinosaur.mask,(offset_x, offset_y))

                    last_bx, last_by = bx, by

                    if overlap:
                        over = True
                        game_over()
                        #加载声音
                        dinosaur.game_over_audio.play()
                        pygame.display.update()
                        pygame.time.delay(3000)

                        run = False
                        return final_score

                    else:
                        if(list[i].rect.x + list[i].rect.width) < dinosaur.rect.x:
                            final_score += list[i].getScore()

                # 显示分数
                    list[i].showScore(final_score)
                    
        if run:
            addObasacletime+=40
            pygame.display.update()
            FPSCLOCK.tick(FPS)

if __name__ == '__main__':
    intro()
    the_score = mainGame()
    print("your score is", the_score)


# ————————————————
# 版权声明：本文为CSDN博主「HUNNU_TN」的原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接及本声明。
# 原文链接：https://blog.csdn.net/qq_44807642/article/details/102810230


  
